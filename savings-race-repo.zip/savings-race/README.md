# Savings Race

A five-minute game about saving, investing, and delayed gratification, aimed at teens and young adults.

You start at 22 with your first paycheque and race **Steady-Bot** — a copy of you with perfect discipline — to age 42. Two scores: end richer than the bot, and drive your **freedom age** as low as you can.

> **Educational simulation, not financial advice.** Market returns are generated, not predicted. See the in-game fine print.

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build into dist/
npm run preview  # serve the production build locally
```

Requires Node 18+.

## Deploy

A GitHub Actions workflow (`.github/workflows/deploy.yml`) publishes to GitHub Pages on every push to `main`. To enable it: **Settings → Pages → Build and deployment → Source: GitHub Actions**. The site lands at `https://<user>.github.io/<repo>/`.

`vite.config.js` sets `base: "./"` so relative asset paths work under a subpath or at a domain root. Netlify, Vercel, or Cloudflare Pages also work with zero config — build command `npm run build`, publish directory `dist`.

## How it works

**Setup** — pick a lifestyle tier and an investment allocation. The lifestyle screen discloses your freedom number (25× annual spending) and roughly what age it's reachable, because lifestyle sets the finish line twice: it drains savings *and* moves the target.

**The race** — 20 years, one turn per year. Quiet years auto-advance; decision years pause. Both you and the bot earn the same income, ride the same market, and live through the same life chapters. The only difference is your choices.

**The debrief** — a gap chart (you minus the bot) with every decision marked, an attribution breakdown of where the gap came from, and ledger sections pricing each decision in compounded dollars and months of delayed freedom.

### Card types

| Type | When | What it tests |
|---|---|---|
| Small one-offs | ages 22–30 | Everyday impulse control, when it matters most |
| Lifestyle routines | ages 30–42 | Recurring commitments — the treats of your 20s, upgraded to defaults |
| Car cycle | 27 / 32 / 37 | The replacement habit; the card tracks your car's true age if you skip |
| Twin trip | 24 and 36 | Identical purchase, two very different true costs |
| House | 31 | Requires the down payment in hand; equity counts in net worth, not the freedom fund |
| Family chapter | 33 | Automatic, hits you and the bot identically — never scored as a choice |
| Panic / re-entry / FOMO / glide path | triggered by the market | Nerve: the behavioural mistakes that cost real investors the most |
| Burnout splurge | happiness floor | Deprivation backfires — a forced impulse buy at a 50% markup |

### Model

- Income grows 5%/yr; inflation runs 2%/yr on lifestyle, every price tag, and the freedom number itself
- ETF ~7% mean with 12% volatility; single stock ~10% mean, 25%+ volatility, fat tails, and a 2%/yr wipeout chance, correlated with the market
- Post-crash rebound bias, so holding through a downturn usually demonstrates its own payoff within a run
- The full 20-year market path is generated up front and shared by player and bot, so luck is never the difference between them
- Happiness drifts down yearly; stuff-joy decays ~50%/yr, experiences leave a small permanent glow, savings milestones add lasting points

All tuning constants sit at the top of `src/SavingsRace.jsx` — `RAISE`, `INFLATION`, `FIRE_MULT`, `JOY_DRIFT`, `JOY_FLOOR`, `CAR_COSTS`, the card pools, and the tier table.

## Design principles

Kept deliberately, and worth preserving in any fork:

- **The bot is you with discipline**, not an optimizer. It copies your lifestyle and your life chapters, budgets for fun, and never reacts to the market. Losing to it is personal; beating it is earned.
- **Fun isn't optional.** The happiness floor exists so total deprivation backfires — a planned fun budget beats willpower that snaps.
- **Family is never scored.** It's a life chapter that hits both racers identically. The game teaches money mechanics; it doesn't grade how anyone lives.
- **Freedom age is a score, not a pass/fail.** Every tier gets a number to race down, so no lifestyle choice is pre-destined to lose.
- **Recurring costs outweigh treats.** One-off purchases dent the gap; routines tilt it. The deck is structured so players discover that themselves.

## Structure

```
index.html
src/
  main.jsx          entry point
  index.css         page-level reset
  SavingsRace.jsx   the whole game: engine, cards, charts, styles
```

Single-component by design — easy to read end to end. A natural next refactor is splitting the simulation engine from the presentation layer, which would also make a kid-mode config pack (allowance-scale money, shorter horizon, two asset choices) straightforward.

## License

MIT — see [LICENSE](LICENSE).
