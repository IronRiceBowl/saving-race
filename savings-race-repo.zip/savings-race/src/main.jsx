import React from "react";
import { createRoot } from "react-dom/client";
import SavingsRace from "./SavingsRace.jsx";
import "./index.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <SavingsRace />
  </React.StrictMode>
);
